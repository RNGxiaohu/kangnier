var todos = [   //可以加详情和时间
	{
		id:1,
		title:'工作',
		todo:[
			{title:'周一早上4点起床打猎',done:false},
			{title:'周五早上8点数学',done:true},
			{title:'周六休息',done:false},
			{title:'周天休息',done:true}
		]
	},
	{
		id:2,
		title:'游戏',
		todo:[
			{title:'周日早上8点英雄联盟',done:false},
			{title:'周六下午四点王者荣耀五黑',done:true},
			{title:'周一晚上开黑三国杀',done:false}
		]
	},
	{
		id:3,
		title:'运动',
		todo:[
			{title:'周三下午打篮球',done:false},
			{title:'周五早上打篮球',done:true},
			{title:'周六中午乒乓球',done:false},
			{title:'周天不下雨看书',done:true}
		]
	}
]
var ctrl = angular.module('ctrl',[]);
ctrl.controller('todo',function($scope){
	$scope.todos = todos;
	$scope.indexShow = 0;

	//修改显示数据下标
	$scope.changeIndex = function(i){
		$scope.indexShow = i;
	}

	//添加分类
	$scope.addCateShow = false;
	$scope.cateTitle = "输入标题";
	$scope.addCate = function(){
		$scope.addCateShow = true;
	}
	$scope.doneCate = function(){
		var id = $scope.todos[$scope.todos.length-1].id;
		$scope.indexShow = $scope.todos.push({
			id:id+1,
			title:$scope.cateTitle,
			todo:[]
		})-1;
		$scope.cancelCate();
	}
	$scope.cancelCate = function(){
		$scope.cateTitle = "输入标题";
		$scope.addCateShow = false;
	}
	//设置标题
	$scope.setTitleShow=false;
	
	$scope.setTitle=function(){
		$scope.cateTitle=$scope.todos[$scope.indexShow].title;
		$scope.setTitleShow=true;
	}

	$scope.doneTitle=function(){
		$scope.todos[$scope.indexShow].title=$scope.cateTitle;
		$scope.cancelTitle();
	}

	$scope.cancelTitle=function(){
		$scope.setTitleShow=false;
	}

	// 完成，未完成设置
	$scope.doneToDoShow=false;
	$scope.ToDoShow=true;


	// 编辑内容
	$scope.editToDo=function(ev,v){
		v.title=ev.target.innerHTML;
	}
	
	// 删除内容
	$scope.delToDo=function(id){
		var data =$scope.todos[$scope.indexShow];
		for(var i in data.todo){
			if(data.todo[i].tid==id){
				data.todo.splice(i,1);
				break;
			}
		}
	}

	// 添加内容
	$scope.addToDo = function(){
		var data =$scope.todos[$scope.indexShow].todo;
		if(data.length==0){	
			var id=1;
		}else{
			var id=data[data.length-1].tid+1;
		}	 
		data.push({
			tid:id,
			title:'',
			done:false
		})
		console.log(data);
	}
})

